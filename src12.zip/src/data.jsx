export const frontend = [
  {
    id: 1,
    img: "/Images/checkmark.png",
    software: "HTML",
    level: "Experienced",
  },
  {
    id: 2,
    img: "/Images/checkmark.png",
    software: "CSS",
    level: "Experienced",
  },
  {
    id: 3,
    img: "/Images/checkmark.png",
    software: "JAVASCRIPT",
    level: "Experienced",
  },
  {
    id: 4,
    img: "/Images/checkmark.png",
    software: "REACT",
    level: "Experienced",
  },
  {
    id: 5,
    img: "/Images/checkmark.png",
    software: "MATERIAL UI",
    level: "Experienced",
  },
  {
    id: 6,
    img: "/Images/checkmark.png",
    software: "GIT",
    level: "Experienced",
  },
];
export const backend = [
  {
    id: 1,
    img: "/Images/checkmark.png",
    software: "POSTGRESQL",
    level: "Basic",
  },
  {
    id: 2,
    img: "/Images/checkmark.png",
    software: "NODE JS",
    level: "Intermediate",
  },
  {
    id: 3,
    img: "/Images/checkmark.png",
    software: "EXPRESS JS",
    level: "Basic",
  },
  {
    id: 4,
    img: "/Images/checkmark.png",
    software: "EXPRESS JS",
    level: "Basic",
  },
];
